#include <iostream>

int get_fibonacci_last_digit(int n) {
  //write your code here
  return 0;
}

int main() {
  int n;
  std::cin >> n;
  int c = get_fibonacci_last_digit(n);
  std::cout << c << '\n';
}
