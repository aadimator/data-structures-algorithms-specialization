#include <iostream>

long long get_fibonaccihuge(long long n, long long m) {
  //write your code here
  return 0;
}

int main() {
    long long n, m;
    std::cin >> n >> m;
    std::cout << get_fibonaccihuge(n, m) << '\n';
}
